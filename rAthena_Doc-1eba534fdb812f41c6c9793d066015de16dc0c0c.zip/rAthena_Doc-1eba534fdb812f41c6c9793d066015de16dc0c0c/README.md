# rAthena_Doc
HTML Documentation of rAthena

## How to use
Just [download](https://github.com/cydh/rAthena_Doc/archive/master.zip) this documentation, extract it, and double-click the HTML file.
